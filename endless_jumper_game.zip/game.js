const canvas = document.getElementById("gameCanvas");
const ctx = canvas.getContext("2d");
canvas.width = window.innerWidth;
canvas.height = window.innerHeight;

let player, platforms, keys, score, isGameRunning = false;

function initGame() {
  player = {
    x: canvas.width / 2,
    y: canvas.height - 100,
    width: 30,
    height: 30,
    color: "#ff6347",
    vx: 0,
    vy: -10,
    gravity: 0.5,
    jumpForce: -10
  };

  score = 0;
  document.getElementById("score").innerText = score;
  platforms = [];
  for (let i = 0; i < 6; i++) {
    platforms.push({
      x: Math.random() * (canvas.width - 60),
      y: i * 120,
      width: 60,
      height: 10,
      color: "#228B22"
    });
  }

  keys = {};
}

document.addEventListener("keydown", e => keys[e.code] = true);
document.addEventListener("keyup", e => keys[e.code] = false);

document.getElementById("leftBtn").addEventListener("touchstart", () => keys["ArrowLeft"] = true);
document.getElementById("leftBtn").addEventListener("touchend", () => keys["ArrowLeft"] = false);
document.getElementById("rightBtn").addEventListener("touchstart", () => keys["ArrowRight"] = true);
document.getElementById("rightBtn").addEventListener("touchend", () => keys["ArrowRight"] = false);

let touchStartX = null;
canvas.addEventListener("touchstart", e => {
  touchStartX = e.changedTouches[0].clientX;
});
canvas.addEventListener("touchend", e => {
  let dx = e.changedTouches[0].clientX - touchStartX;
  if (dx < -50) keys["ArrowLeft"] = true;
  if (dx > 50) keys["ArrowRight"] = true;
  setTimeout(() => {
    keys["ArrowLeft"] = false;
    keys["ArrowRight"] = false;
  }, 200);
});

function update() {
  player.vy += player.gravity;
  player.y += player.vy;
  if (keys["ArrowLeft"]) player.x -= 5;
  if (keys["ArrowRight"]) player.x += 5;

  platforms.forEach(p => {
    if (
      player.vy > 0 &&
      player.x + player.width > p.x &&
      player.x < p.x + p.width &&
      player.y + player.height > p.y &&
      player.y + player.height < p.y + p.height + player.vy
    ) {
      player.vy = player.jumpForce;
      score++;
      document.getElementById("score").innerText = score;
    }
  });

  if (player.y < canvas.height / 2) {
    platforms.forEach(p => {
      p.y += Math.abs(player.vy);
      if (p.y > canvas.height) {
        p.y = 0;
        p.x = Math.random() * (canvas.width - 60);
      }
    });
    player.y += Math.abs(player.vy);
  }

  if (player.y > canvas.height) {
    alert("Game Over! Your score: " + score);
    location.reload();
  }
}

function draw() {
  ctx.clearRect(0, 0, canvas.width, canvas.height);
  ctx.fillStyle = player.color;
  ctx.fillRect(player.x, player.y, player.width, player.height);
  platforms.forEach(p => {
    ctx.fillStyle = p.color;
    ctx.fillRect(p.x, p.y, p.width, p.height);
  });
}

function gameLoop() {
  if (isGameRunning) {
    update();
    draw();
  }
  requestAnimationFrame(gameLoop);
}

function startGame() {
  document.getElementById("menu").style.display = "none";
  document.getElementById("scoreBoard").style.display = "block";
  document.getElementById("controls").style.display = "block";
  isGameRunning = true;
  initGame();
}

gameLoop();
